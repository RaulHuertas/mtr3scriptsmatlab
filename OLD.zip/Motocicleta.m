classdef Motocicleta  < handle
    properties
        k  {mustBeNumeric} = 1;
        c  {mustBeNumeric} = 1;
        dMax  {mustBeNumeric} = 0.13;
        dActual  {mustBeNumeric} = 0.;
    end
    methods
        function r =  fuerza(obj)
            r = obj.k*obj.dActual;
        end
    end
end