classdef Rueda  < handle
    properties
        radioExterno  {mustBeNumeric} = 1;
        radioSeccion  {mustBeNumeric} = 1;
        presion  {mustBeNumeric} = 0.13; % en MPa
        anguloInclinacion  {mustBeNumeric} = 0.;
        masa
    end
    methods
        
    end
end