classdef Perceptron  < handle
    properties
        a  {mustBeNumeric} = 1;
        b  {mustBeNumeric} = 1;
        c  {mustBeNumeric} = 0;
        n  {mustBeNumeric} = 0.1
    end
    methods
        function train(obj, x, y, mustBePositiveQ)
            error = (obj.eval(x,y));
%             error = 1;
%             d_err_a = -x*error;
%             d_err_b = -y*error;
%             d_err_c = -1*error;
            d_err_a = 0;
            d_err_b = 0;
            d_err_c = 0;
            if mustBePositiveQ && error<0
                d_err_a = -x;
                d_err_b = -y;
                d_err_c = -1;
            elseif ~mustBePositiveQ && error>=0
                d_err_a = x;
                d_err_b = y;
                d_err_c = 1;
            end
            
%             if mustBePositiveQ
%                 fprintf("\nmustBePositiveQ: 1\n");
%             else
%                 fprintf("\nmustBePositiveQ: 0\n");
%             end   
%             fprintf("error: " + num2str(error) + "\n");
%             fprintf("d_err_a: " + num2str(d_err_a) + "\n");
%             fprintf("d_err_b: " + num2str(d_err_b) + "\n");
%             fprintf("d_err_c: " + num2str(d_err_c) + "\n");
            
            obj.a = obj.a-obj.n*d_err_a;
            obj.b = obj.b-obj.n*d_err_b;
            obj.c = obj.c-obj.n*d_err_c;
            
%             r = obj;
        end
        
        function r = eval(obj, x, y)
            r = obj.a*x+obj.b*y+obj.c;
        end
        
    end
end
